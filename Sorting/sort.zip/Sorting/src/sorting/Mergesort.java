/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

/**
 *
 * @author M.Ahsan
 */
public class Mergesort {

    private int low;
    private int mid;
    private int high;
    private int[] list;
    private int maxsize;
    private int[] sortedlist;

    public Mergesort(int size) {
        this.maxsize = size;
        this.list = new int[size];
        this.sortedlist=new int[size];
        this.low = 0;
        this.high = this.maxsize - 1;
        this.mid=(this.low+this.high)/2;
    }
public int[] gettsortedlist(){
return this.sortedlist;
}
    public int getmaxsize() {
        return this.maxsize;
    }

    public int getlow() {
        return this.low;
    }

    public int gethigh() {
        return this.high;
    }

    public int getmid() {
        return this.mid;
    }
    public int[] getlist(){
    return this.list;}

    public void setlow(int low) {
        this.low = low;
    }

    public void setmid(int mid) {
        this.mid = mid;
    }

    public void sethigh(int high) {
        this.high = high;
    }
    
}    

    public void mergesort(int[] list, int low, int high) {
        if (this.gethigh() == this.getlow()) {
        } else {
            this.mergesort( this.getlist(),this.getlow(),this.getmid());
            this.mergesort(this.getlist(), this.getmid()+1, this.gethigh());
            this.merge(this.getlist(),this.getlow(), this.getmid()+1, this.gethigh());
        }
        
    }
    public void merge(int[] list,int lowindex,int midindex,int highindex){
        if(list[lowindex]<list[highindex]){
            
        }else if(list[lowindex]>list[highindex]){
        
        }
    }
};
