/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text;

import ds.HashTable;
import ds.node;
import java.net.URL;
import java.util.Collection;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;
import org.controlsfx.control.textfield.AutoCompletionBinding;
import org.controlsfx.control.textfield.TextFields;


/**
 *
 * @author M.Ahsan
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private AnchorPane root;
    @FXML
    private TextField input;
    //HashTable ht=new HashTable(10);
    //private AutoCompletionBinding<String> autocomplete;
    Set<String> possiblewords=new HashSet<>();
    private AutoCompletionBinding<String> autocomplete;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        autocomplete=TextFields.bindAutoCompletion(input,possiblewords);
        input.setOnKeyPressed((KeyEvent e)->{
        switch(e.getCode()){
            case ENTER:
                learnwords(input.getText());
                break;
            default:
                break;
        
        }
        });
    

    }


    private void learnwords(String text) {
      //ht.insert(text);
      possiblewords.add(text);
      if(autocomplete!=null){
      autocomplete.dispose();
      }
      autocomplete=TextFields.bindAutoCompletion(input,possiblewords);
    }
    
}
